var logo = document.getElementById("logo");
var sidebar = document.getElementById("sidebar");

console.log(sidebar);

logo.addEventListener("click", function () {
   //    sidebar.style.left = "0px";
   sidebar.classList.toggle("active-sidebar");
});
